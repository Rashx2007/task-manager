"use client";
import { useState, useEffect } from "react";
import FileBrowser from "./FileBrowser";
import { showToast } from "@/lib/toast";

const SHARE_FOLDER = "E:\\Share(Tasks)";

export default function FolderModal({ taskId, onClose, onSaved }) {
  const [form, setForm] = useState(null);
  const [saving, setSaving] = useState(false);
  const [showBrowse, setShowBrowse] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch(`/api/folder?taskId=${taskId}`);
        const d = await res.json();
        if (d.success) setForm(d.data || { FolderPath: "", FileName: "" });
      } catch {
        setForm({ FolderPath: "", FileName: "" });
      }
    })();
  }, [taskId]);

  const full = () => {
    const folder = String(form?.FolderPath || "").trim();
    const file = String(form?.FileName || "").trim();
    if (!file) return folder;
    if (/^([A-Za-z]:[\/\\])/.test(file)) return file;
    if (!folder) return file;
    return folder.replace(/[\/\\]+$/, "") + "\\" + file;
  };

  const openPath = async (p) => {
    try {
      const res = await fetch("/api/open-path", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ path: p }),
      });
      const d = await res.json();
      if (!d.success) showToast(d.error || "بازکردن مسیر ممکن نشد.", "error");
      else if (d.adjusted)
        showToast("مسیر دقیق یافت نشد؛ نزدیک‌ترین پوشهٔ موجود باز شد:\n" + d.opened, "warn");
      else showToast("مسیر در ویندوز باز شد.", "success", 2500);
    } catch {
      showToast("خطا در ارتباط با سرور.", "error");
    }
  };

  const copyPath = async () => {
    const p = full();
    if (!p) {
      alert("مسیری برای کپی وجود ندارد.");
      return;
    }
    try {
      await navigator.clipboard.writeText(p);
      alert("مسیر در کلیپ‌بورد کپی شد.");
    } catch {
      alert("کپی ممکن نشد.");
    }
  };

  const copyMirror = async () => {
    const src = String(form?.FolderPath || "").trim();
    if (!src) {
      alert("پوشهٔ مبدأ ثبت نشده است.");
      return;
    }
    if (!confirm("کل محتوای پوشه به‌صورت آینه‌ای در مقصد اشتراکی کپی شود؟")) return;
    const dest = prompt("پوشهٔ مقصد برای کپی:", SHARE_FOLDER);
    if (!dest) return;
    try {
      const res = await fetch("/api/folder/mirror", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ src, dest }),
      });
      const d = await res.json();
      if (d.success) alert("کل محتوای پوشه به‌صورت آینه‌ای کپی شد به:\n" + d.dest);
      else alert("خطا: " + d.error);
    } catch {
      alert("خطا در ارتباط با سرور");
    }
  };

  const save = async () => {
    setSaving(true);
    try {
      const res = await fetch("/api/folder", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          taskId,
          FolderPath: form.FolderPath || "",
          FileName: form.FileName || "",
        }),
      });
      const d = await res.json();
      if (d.success) {
        alert("ذخیره شد.");
        if (onSaved) onSaved();
        onClose();
      } else alert("خطا: " + d.error);
    } catch {
      alert("خطا در ارتباط با سرور");
    }
    setSaving(false);
  };

  const inp = "search-input w-full";
  if (!form) return null;

  return (
    <div
      className="fixed inset-0 bg-black/50 flex items-center justify-center z-[9999]"
      onClick={(e) => {
        e.stopPropagation();
        if (e.target === e.currentTarget) onClose();
      }}
      onMouseDown={(e) => {
        e.stopPropagation();
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="bg-[#CCE6DF] rounded-lg shadow-2xl w-[560px] max-w-[95vw] p-6">
        <h3 className="text-lg font-bold mb-4">پوشهٔ ضمائم — کد کار: {taskId}</h3>

        <label className="block text-sm font-bold mb-1">مسیر پوشه</label>
        <div className="flex gap-2 mb-3">
          <input
            className={inp}
            dir="ltr"
            value={form.FolderPath || ""}
            onChange={(e) => setForm({ ...form, FolderPath: e.target.value })}
          />
          <button type="button" className="btn-primary whitespace-nowrap" onClick={() => setShowBrowse(true)}>
            📂 مرور
          </button>
        </div>

        <label className="block text-sm font-bold mb-1">فایل انتخابی</label>
        <input
          className={inp + " mb-4"}
          dir="ltr"
          value={form.FileName || ""}
          onChange={(e) => setForm({ ...form, FileName: e.target.value })}
        />

        <div className="flex flex-wrap gap-2 mb-4">
          <button type="button" className="btn-primary" onClick={() => openPath(full())}>
            📁 بازکردن پوشه/فایل
          </button>
          <button type="button" className="btn-primary" onClick={copyPath}>
            ⧉ کپی مسیر
          </button>
          <button type="button" className="btn-primary" onClick={copyMirror}>
            🪞 کپی آینه‌ای
          </button>
        </div>

        <div className="flex gap-2 justify-end">
          <button className="btn-success" disabled={saving} onClick={save}>
            ذخیره
          </button>
          <button className="btn-danger" onClick={onClose}>
            بستن
          </button>
        </div>
      </div>

      {showBrowse && (
        <FileBrowser
          defaultPath={form.FolderPath || "D:\\"}
          onClose={() => setShowBrowse(false)}
          onSelect={(p) => {
            setForm({ ...form, FolderPath: p });
            setShowBrowse(false);
          }}
        />
      )}
    </div>
  );
}